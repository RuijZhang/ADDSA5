# kirby21.MRICloud
A dataset containing correlation data for 20 subjects from Kennedy Krieger.

[![Travis-CI Build Status](https://travis-ci.org/adigherman/kirby21.mricloud.svg?branch=master)](https://travis-ci.org/adigherman/kirby21.mricloud) [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/adigherman/kirby21.mricloud?branch=master&svg=true)](https://ci.appveyor.com/project/adigherman/kirby21.mricloud)